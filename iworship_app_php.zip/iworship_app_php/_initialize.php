<?php 
 session_start();
 include_once("./connect/connect_me_to_db.php");
 
 // Date and time variables
$date = date('D d - m - Y');
 
 $second = date('s');
 $minute = date('i');
 $hour = (date('H')-1);
 if($hour > 12){
	 $hour = $hour - 12;
	 $time = $hour .":". $minute .":". $second. " PM";
 }
 else{
	$time = $hour .":". $minute .":". $second. " AM";
 }

 
 // It returns a UserId if the user exists
 function signInCheck($username, $password, $conn){
	$username = mysqli_real_escape_string($conn,trim($username));
	$password = mysqli_real_escape_string($conn,trim($password));
	
	$queryUser = mysqli_query($conn,"SELECT *
		FROM users
		WHERE ((Username = '$username') AND (Password = '$password') AND (Deactivated='No'))");
	if(mysqli_num_rows($queryUser) > 0){	
			$row = mysqli_fetch_assoc($queryUser);
			$userId = $row['User_Id'];
		
		//If the query is successful, We return the user_Id of the user so that it can be used by other functions		
		 return $userId;	
	}
	else{
		return "failed";
	}
 }
 
 // This function fetches the details of the user with the passed userId
 // returns a json array if successful
 function fetchUserDetailsWithUserId($userId, $conn){
	$userId = mysqli_real_escape_string($conn,trim($userId));

	$data = array(); 
	
	$queryUser = mysqli_query($conn,"SELECT *
		FROM users
		WHERE ((User_Id = '$userId') AND Deactivated='No')");
	if(mysqli_num_rows($queryUser)>0){	
	
		$response = array();
		while($row = mysqli_fetch_assoc($queryUser)){
			$response[] = $row;
		}
		// After the while loop
			 $data = $response;
	}
	else{
		echo "failure";
	}
	
//displaying the data in json format 
echo json_encode($data);

 }
 
 
 // It returns a UserId if the user exists
 function signUpCheck($username, $password, $email, $conn, $date, $time){
	$username = mysqli_real_escape_string($conn,trim($username));
	$password = mysqli_real_escape_string($conn,trim($password));
	$email = mysqli_real_escape_string($conn,trim($email));
	
	$queryUser = mysqli_query($conn,"SELECT *
		FROM users
		WHERE ((Username = '$username') OR (Email = '$email'))");
	if(mysqli_num_rows($queryUser) < 1){
	
			$insertUser = mysqli_query($conn,"INSERT INTO `users` (`Username`,`Email`, `Password`, `Deactivated`,`Registered_Date`, `Registered_Time`) VALUES ('$username', '$email',  '$password','No','$date', '$time')");
										
			if($insertUser){
				echo "successful";
			}
			else{
				echo "failed";
			}
	}
	else{
		echo "user_exists";
	}
 }
 
 
 // It returns all the songs as a json array
 function fetchAllSongs($conn){
 $heroes = array(); 
	$result = mysqli_query($conn,"SELECT *
		FROM songs
		WHERE Song_Status='available' ORDER BY Song_Id DESC
		");
	if(mysqli_num_rows($result) > 0){
	
		$response = array();
		while($row = mysqli_fetch_array($result)){  // The variable $row is an array(i.e. from database)

			$response[] = $row;
		}
		
		$heroes = $response;
	}
	else{
		echo "failed";
	}
	
	echo json_encode($heroes);
 }
 
 ?>
 
 