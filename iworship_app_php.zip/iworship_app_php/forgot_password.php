<?php 
 include_once("./_initialize.php");
if(isset($_POST['passwordEmail'])){							
							$user_email = mysqli_real_escape_string($conn,trim($_POST['passwordEmail']));
							
						$query_db_with_email = mysqli_query($conn,"SELECT * FROM users WHERE Email = '$user_email'");
						$count = mysqli_num_rows($query_db_with_email);
								if($count>0){
									$hold_user_detail = mysqli_fetch_assoc($query_db_with_email);
									$this_user_id  = $hold_user_detail['User_Id'];
									$this_user_name = $hold_user_detail['Username'];
									$this_user_password = $hold_user_detail['Password'];
									
									$mail_to_address = $user_email; 
									$subject = "Forgotten password request";
									$msg = "Dear ".$this_user_name."! you requested for a password retrieval. If you are not the one, please simply ignore this message!  \n
									Your password is: ".$this_user_password." \n
									Please you may change this passwrod for security reasons. Thank you.
									";
									
									$send_mail = mail($mail_to_address, $subject, $msg);
									if($send_mail){
										echo "success";
									}
									else{
										echo "failed";
									}
								}
								else{ // if the user does not exist.
									echo "failed";
								}
							}
				?>