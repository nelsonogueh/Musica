-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2018 at 05:56 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `iworship`
--

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE IF NOT EXISTS `songs` (
  `Song_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Song_Title` varchar(200) DEFAULT NULL,
  `Song_Genre` varchar(100) DEFAULT NULL,
  `Song_Status` varchar(50) DEFAULT NULL COMMENT 'available or not_available',
  `Song_Path` varchar(200) DEFAULT NULL,
  `Song_Cover_Image` varchar(200) DEFAULT NULL,
  `Uploaded_Date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Song_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`Song_Id`, `Song_Title`, `Song_Genre`, `Song_Status`, `Song_Path`, `Song_Cover_Image`, `Uploaded_Date`) VALUES
(1, 'You raised up', 'R and B', 'available', 'songs/you_raised_me_up.mp3', 'song_cover_image/you_raised_me_up.jpg', '02-04-2018'),
(2, 'Yahweh', 'Gospel', 'not_available', 'songs/yahweh.mp3', 'song_cover_image/you_raised_me_up.jpg', '14-07-2017'),
(3, 'Break Every Chain', 'Gospel', 'available', 'songs/break_every_chain.mp3', 'song_cover_image/break_every_chain.jpg', '05-10-2017');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `User_Id` int(50) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Deactivated` varchar(10) DEFAULT NULL,
  `Last_Signin_Date` varchar(20) DEFAULT NULL,
  `Registered_Date` varchar(20) DEFAULT NULL,
  `Registered_Time` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`User_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_Id`, `Username`, `Email`, `Password`, `Deactivated`, `Last_Signin_Date`, `Registered_Date`, `Registered_Time`) VALUES
(10001, 'ovovwe', 'Nelsonovovwe@gmail.com', 'nelson', 'No', NULL, '20/02/2018', '08:15 PM'),
(10002, 'bless', 'nelson@gggg.com', 'nelsonkkkk', 'No', NULL, 'Thu 12 - 04 - 2018', '1:00:11 AM');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
