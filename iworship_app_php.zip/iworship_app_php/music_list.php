<?php 
   include_once("./_initialize.php");
	
	fetchAllSongs($conn);
 ?>