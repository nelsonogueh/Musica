<?php 
   include_once("./_initialize.php");
   if((isset($_REQUEST['usernameSent']))&&(isset($_REQUEST['passwordSent']))){
 $username = mysqli_real_escape_string($conn,trim($_REQUEST['usernameSent']));
  $password = mysqli_real_escape_string($conn,trim($_REQUEST['passwordSent']));
 
	if(!(signInCheck($username, $password, $conn)=="failed")){
			$user_id = signInCheck($username, $password, $conn);
			
			// If the user Id exists, we fetch the user's details
			fetchUserDetailsWithUserId($user_id, $conn);
	}
	else{
		echo "failed";
	}
 }
 else{
	echo "failed";
 }
 
 ?>