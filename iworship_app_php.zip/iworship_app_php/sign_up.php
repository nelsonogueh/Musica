  <?php 
include_once("./_initialize.php");
 
 $form_email = mysqli_real_escape_string($conn,trim($_REQUEST['emailSent']));
 $form_password = mysqli_real_escape_string($conn,trim($_REQUEST['passwordSent']));
 $form_username=mysqli_real_escape_string($conn,trim($_REQUEST['usernameSent']));
 
 // We first check if the username already exists
 if(((isset($form_email))&& (strlen($form_email)>=6)) && ((isset($form_password))&& (strlen($form_password)>=6))&& ((isset($form_username))&& (strlen($form_username)>=3))){
 
	signUpCheck($form_username, $form_password, $form_email, $conn, $date, $time);
 
 }
 else{
	echo "input_too_short";
 }
 ?>